package excel;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.IOException;

public class ReadExcel {
	public static String readExcel(int i,int j) throws IOException {
		/*
		  Getting the Relative path for excel from Source Excel folder
		 */
		String filePath = System.getProperty("user.dir")+"//Excel//Test Data.xlsx";
		FileInputStream file = new FileInputStream(filePath);
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet ws = wb.getSheetAt(0);
		String testData = String.valueOf(ws.getRow(i).getCell(j));
		wb.close();
		return testData;
	}


}
