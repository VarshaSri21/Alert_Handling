package browser;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;

public class Browser {
	public static WebDriver driver;
	
	 public static WebDriver getWebDriver() {
		 try {
		 while(true) {
			
				System.out.println("Enter Browser Name Chrome/Firefox or 0 to Exit");
				Scanner scan = new Scanner(System.in);
				String browser = scan.nextLine();
				scan.close();
				if(browser.equalsIgnoreCase("0")) {
				System.out.println("Program terminatted");
				System.exit(0);
				}
				else if(browser.equalsIgnoreCase("chrome")) {
				/*To launch application in Chrome browser*/
					String driverPath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
					System.setProperty("webdriver.chrome.driver", driverPath);
					driver = new ChromeDriver();
				break;
				}
				/*To launch application in Fire fox browser*/
				else if(browser.equalsIgnoreCase("firefox")) {
					String driverPath = System.getProperty("user.dir") + "\\Drivers\\geckodriver.exe";
					System.setProperty("webdriver.gecko.driver", driverPath);
				FirefoxOptions options = new FirefoxOptions();
				options.setProfile(new FirefoxProfile());
				options.addPreference("dom.webnotifications.enabled", false);
				driver = new FirefoxDriver(options);
				break;
				}
				else{
					System.out.println("Invalid Browser");
					
				}
			} 
		 }catch(Exception e) {
				e.printStackTrace();
				
			}
		return driver;
				
	 }
	 /* getting url
	  */
	 public static void getUrl() throws Exception {
		 try {
			String filelocation = System.getProperty("user.dir") + "\\ApplicationProperties\\configure.properties";
			File file = new File(filelocation);
			FileInputStream fileinput = new FileInputStream(file);
			Properties prop = new Properties();
			prop.load(fileinput);
			
			driver.navigate().to(prop.getProperty("url"));
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
		 catch(Exception e) {
				e.printStackTrace();
		 }
		
	 }





}
