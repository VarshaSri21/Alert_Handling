package screenshot;
import java.io.IOException;

import home.Home;

import java.io.File;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
//Capturing Screenshot
public class CaptureScreenshot extends Home{
	public static int i=0;
	public static void screenShot() throws IOException,Exception{	
		try {
			BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));	//Taking Screenshot
			ImageIO.write(image, "jpg", new File(System.getProperty("user.dir")+"\\ScreenShot\\Screenshot"+i+".jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		i++;
	}
}
