package locators;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import home.Home;

public class Locators extends Home{
	/*
	 Acquiring the properties of browser using super key 
	 * */
	
	public Locators() throws Exception{
		super();
	}
	/*Method to get element of Sign in Button 
	 and store it*/
	public static WebElement signInButton() {
		
		WebElement signIn=null;
		try {
			signIn=driver.findElement(By.name("proceed"));
		}catch(Exception e) {
		System.out.println(e);
		}
		return signIn;
	}
	/*Method to get element of forgot password Link 
	  and store it*/
	public static WebElement forgotPassword() {
		WebElement forgetPass=null;
		try {
			forgetPass=driver.findElement(By.xpath("//u[contains(text(),'Forgot Password?')]"));
		}catch(Exception e) {
		System.out.println(e);
		}
		return forgetPass;
	}
	/*Method to get element of Next Button 
	 and store it*/
	public static WebElement nextButton() {
		WebElement next=null;
		try {
			next=driver.findElement(By.name("next"));
		}catch(Exception e) {
		System.out.println(e);
		}
		return next;
	}
}
