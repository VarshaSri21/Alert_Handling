package home;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import browser.Browser;
import excel.ReadExcel;
import locators.Locators;
import screenshot.CaptureScreenshot;

public class Home {
	public static WebDriver driver;  //Static variable to initialize driver in selinium webdriver
	int i=0,j=0;
	public WebDriver setupDriver() throws Exception {         //Invoking driver using getWebDriver method from DriverSetup class
		 driver = Browser.getWebDriver();
		 return driver;
	}
	/* 
	 Invoking method  to get element for sign in and click it.
	 It can take the screenshot of alert box using CaptureScreen class.
	 It can read the input from the excel file.
	 Compare the actual input with expected.
	 */
	public void clickSignin() throws InterruptedException,IOException { 
		try {
			WebElement signin=Locators.signInButton();
			driver.findElement(By.id("login1")).sendKeys("");
			driver.findElement(By.name("passwd")).sendKeys("");
			signin.click();     // click on signin 
			sleep(1000);
			CaptureScreenshot.screenShot();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			Alert alert1=driver.switchTo().alert();/*Switcshing to Alert*/
			String act1 = driver.switchTo().alert().getText();/*Capturing Alert Message*/
			alert1.accept();/*Accepting alert*/
			String exp1 = ReadExcel.readExcel(i,j); // Read the input from excel file
			if(act1.contains(exp1))              // compare date actual with expected
			{
				System.out.println(act1);
			}else
			{
				System.out.println("Alert is not displayed");
			}
			i++;
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	/*
	 Invoking method  to get element for forgotpassword in and click it. 
	 It can click on next and click it.
     It can take the screenshot of alert box using CaptureScreen class.
     It can read the input from the excel file.
     Compare the actual input with expected.
	  */
	public void clickForgotPassword() throws InterruptedException, IOException {
		
		try {
			WebElement forgetPass=Locators.forgotPassword();
			forgetPass.click();              // click on forgot password
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebElement next=Locators.nextButton();
			next.click();   //click on next
			sleep(2000);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			CaptureScreenshot.screenShot();
			Alert alert2=driver.switchTo().alert();/*Switching to Alert*/
			String act2 = driver.switchTo().alert().getText();/*Capturing Alert Message*/
			alert2.accept();/*Accepting alert*/
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			String exp2 = ReadExcel.readExcel(i,j);                              //Read input from the excel 
			if(act2.contains(exp2))
			{
				System.out.println(act2);                       // compare actual input with expected
			}else
			{
				System.out.println("Alert is not displayed");
			}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	/* 
	 closing the browser.
	 */
	
	public void closeBrowser() { 
		driver.close();
	}
	public static void sleep(int millis) throws InterruptedException {
		Thread.sleep(millis);
	}

	public static void main(String[] args) throws InterruptedException,IOException,Exception{
		// TODO Auto-generated method stub
		Home obj = new Home();
		obj.setupDriver();
		Browser.getUrl();
		obj.clickSignin();
		obj.clickForgotPassword();
		obj.closeBrowser();
		


	}

}



